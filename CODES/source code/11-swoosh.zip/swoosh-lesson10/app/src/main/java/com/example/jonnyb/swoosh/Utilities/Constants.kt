package com.example.jonnyb.swoosh.Utilities

/**
 * Created by jonnyb on 8/17/17.
 */

const val EXTRA_PLAYER = "player"
